function toggleMenu(){document.querySelector('nav').classList.toggle('show')}
const form=document.getElementById('contactForm');
if(form){form.addEventListener('submit',e=>{e.preventDefault();document.getElementById('formMsg').textContent='✓ Thanks! Your enquiry has been received.';form.reset();});}
