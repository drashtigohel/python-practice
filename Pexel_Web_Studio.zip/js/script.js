function toggleMenu(){document.querySelector('nav').classList.toggle('show')}
const form=document.getElementById('contactForm');
if(form){form.addEventListener('submit',e=>{e.preventDefault();document.getElementById('formMsg').textContent='Thank you! Your message has been received. We will contact you soon.';form.reset();});}
